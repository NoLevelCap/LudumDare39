<?php
  $servername = "160.153.128.3";
  $username = "ld39gameuser";
  $password = "ld39gameuserpass";
  $dbname = "gamesdata";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "INSERT INTO `gamesdata`.`L39_PIRATEGAME_START` (`id`, `time`, `shipname`, `areaname`) VALUES (NULL, CURRENT_TIMESTAMP, '".$_POST['shipname']."', '".$_POST_['areaname']."');";

  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }
 ?>
