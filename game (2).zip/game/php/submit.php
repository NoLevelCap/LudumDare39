<?php
  $servername = "160.153.128.3";
  $username = "ld39gameuser";
  $password = "ld39gameuserpass";
  $dbname = "gamesdata";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "INSERT INTO `gamesdata`.`LD39_PIRATEGAME_LOG_1` (`id`, `timeofsubmission`,
    `shipname`, `areaname`, `gold`, `crew`, `time`, `IsGood`)
    VALUES (NULL, CURRENT_TIMESTAMP, '" . $_POST["shipname"] . "' , '" . $_POST["areaname"] . "', '" . $_POST["gold"] . "', '" . $_POST["crew"] . "', '" . $_POST["time"] . "', '1')";

  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  $sql = "SELECT id, shipname, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE (shipname = '".$_POST["shipname"]."') AND (areaname = '".$_POST["areaname"]."')  AND (time = '".$_POST["time"]."')";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo '{ "iden":' . json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, gold, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE gold = (SELECT Max(gold) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1`) ";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "global_gold":' .json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, gold, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE gold = (SELECT Max(gold) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE areaname = '".$_POST["areaname"]."')";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "local_gold":' . json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, crew, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE crew = (SELECT Max(crew) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1`) ";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "global_crew":' . json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, crew, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE crew = (SELECT Max(crew) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE areaname = '".$_POST["areaname"]."')";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "local_crew":' . json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, time, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE time = (SELECT Min(time) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1`) ";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "global_time":' . json_encode($result->fetch_assoc()) . ",\n";

  $sql = "SELECT id, shipname, time, areaname FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE time = (SELECT Min(time) FROM `gamesdata`.`LD39_PIRATEGAME_LOG_1` WHERE areaname = '".$_POST["areaname"]."')";
  $result = $conn->query($sql);
  if(!$result){
    die($conn->error);
  }

  echo ' "local_time":' . json_encode($result->fetch_assoc()) . "}\n";

  $conn->close();
?>
